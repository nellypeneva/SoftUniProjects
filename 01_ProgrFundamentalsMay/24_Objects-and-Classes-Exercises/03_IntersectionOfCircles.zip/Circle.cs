﻿namespace _03_IntersectionOfCircles
{
    public class Circle
    {
        public Point Point { get; set; }
        public double Radius { get; set; }
    }
}
