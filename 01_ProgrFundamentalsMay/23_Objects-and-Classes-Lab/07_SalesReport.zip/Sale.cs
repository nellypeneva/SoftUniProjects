﻿namespace _07_SalesReport
{
    public class Sale
    {
        public decimal Price {get; set;}
        public string Town { get; set; }
        public string Product { get; set; }
        public decimal Quantity { get; set; }
    }
}
