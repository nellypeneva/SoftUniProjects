﻿namespace _03_IntersectionOfCircles
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
